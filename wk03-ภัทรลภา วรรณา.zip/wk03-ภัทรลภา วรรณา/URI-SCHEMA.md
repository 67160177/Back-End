# Student API

|   Method   | URI                     | คำอธิบาย                                              |             Status Code ที่เป็นไปได้             |
| :--------: | :---------------------- | :---------------------------------------------------- | :----------------------------------------------: |
|  **GET**   | `/api/v1/students`      | ดึงรายชื่อนักศึกษาทั้งหมด                             |                     `200 OK`                     |
|  **GET**   | `/api/v1/students/{id}` | ดึงข้อมูลนักศึกษารายบุคคล (รองรับ `?include=courses`) |            `200 OK`, `404 Not Found`             |
|  **POST**  | `/api/v1/students`      | เพิ่มนักศึกษาใหม่                                     | `201 Created`, `400 Bad Request`, `409 Conflict` |
|  **PUT**   | `/api/v1/students/{id}` | แก้ไขข้อมูลนักศึกษาทั้งระเบียน                        |   `200 OK`, `400 Bad Request`, `404 Not Found`   |
| **PATCH**  | `/api/v1/students/{id}` | แก้ไขข้อมูลนักศึกษาบางส่วน                            |            `200 OK`, `404 Not Found`             |
| **DELETE** | `/api/v1/students/{id}` | ลบนักศึกษา                                            |            `200 OK`, `404 Not Found`             |
