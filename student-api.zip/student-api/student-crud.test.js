jest.mock("./db");
jest.mock("./cache", () => ({
  redisClient: { del: jest.fn().mockResolvedValue(1) },
}));

const pool = require("./db");
const request = require("supertest");
const app = require("./app");
const { generateToken } = require("./auth-helpers");

describe("Student CRUD API", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe("POST /api/v1/students", () => {
    test("should create student", async () => {
      pool.query.mockResolvedValueOnce([
        {
          insertId: 10,
        },
      ]);

      const response = await request(app).post("/api/v1/students").send({
        name: "Test Student",
        major: "IT",
        email: "teststudent@example.com",
      });

      expect(response.status).toBe(201);
    });

    test("should reject invalid data", async () => {
      const response = await request(app).post("/api/v1/students").send({
        name: "",
      });

      expect(response.status).toBe(400);
    });
  });

  describe("PUT /api/v1/students/:id", () => {
    test("should update student", async () => {
      pool.query.mockResolvedValueOnce([
        {
          affectedRows: 1,
        },
      ]);
      pool.query.mockResolvedValueOnce([[{ id: 1 }]]);

      const response = await request(app).put("/api/v1/students/1").send({
        name: "Updated Student",
        major: "IT",
        email: "updated@example.com",
      });

      expect(response.status).toBe(200);
    });

    test("should return 404 when student not found", async () => {
      pool.query.mockResolvedValueOnce([
        {
          affectedRows: 0,
        },
      ]);

      const response = await request(app).put("/api/v1/students/999").send({
        name: "Not Found",
        major: "IT",
        email: "notfound@example.com",
      });

      expect(response.status).toBe(404);
    });
  });

  describe("PATCH /api/v1/students/:id", () => {
    test("should partially update student", async () => {
      pool.query.mockResolvedValueOnce([
        {
          affectedRows: 1,
        },
      ]);
      pool.query.mockResolvedValueOnce([[{ id: 1 }]]);

      const response = await request(app).patch("/api/v1/students/1").send({
        name: "Patch Student",
      });

      expect(response.status).toBe(200);
    });

    test("should reject empty patch", async () => {
      const response = await request(app).patch("/api/v1/students/1").send({});

      expect(response.status).toBe(400);
    });
  });

  describe("DELETE /api/v1/students/:id", () => {
    test("admin should delete student", async () => {
      const token = generateToken({
        id: 99,
        email: "admin@example.com",
        role: "admin",
      });

      pool.query.mockResolvedValueOnce([
        {
          affectedRows: 1,
        },
      ]);

      const response = await request(app)
        .delete("/api/v1/students/1")
        .set("Authorization", `Bearer ${token}`);

      expect(response.status).toBe(200);
    });

    test("admin delete should return 404 if student not found", async () => {
      const token = generateToken({
        id: 99,
        email: "admin@example.com",
        role: "admin",
      });

      pool.query.mockResolvedValueOnce([
        {
          affectedRows: 0,
        },
      ]);

      const response = await request(app)
        .delete("/api/v1/students/999")
        .set("Authorization", `Bearer ${token}`);

      expect(response.status).toBe(404);
    });
    test("PUT should reject missing required fields", async () => {
      const response = await request(app).put("/api/v1/students/1").send({
        name: "Only Name",
      });

      expect(response.status).toBe(400);
    });

    test("PATCH should update email", async () => {
      pool.query.mockResolvedValueOnce([
        {
          affectedRows: 1,
        },
      ]);
      pool.query.mockResolvedValueOnce([[{ id: 1 }]]);

      const response = await request(app).patch("/api/v1/students/1").send({
        email: "newemail@example.com",
      });

      expect(response.status).toBe(200);
    });

    test("PATCH should update major", async () => {
      pool.query.mockResolvedValueOnce([
        {
          affectedRows: 1,
        },
      ]);
      pool.query.mockResolvedValueOnce([[{ id: 1 }]]);

      const response = await request(app).patch("/api/v1/students/1").send({
        major: "ITDI",
      });

      expect(response.status).toBe(200);
    });
  });
});
