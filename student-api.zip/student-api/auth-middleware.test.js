const request = require("supertest");
const app = require("./app");
const { generateToken } = require("./auth-helpers");

describe("Authentication Middleware", () => {
  test("should return 401 when token is missing", async () => {
    const response = await request(app).get("/api/v1/auth/me");

    expect(response.status).toBe(401);
    expect(response.body.error.code).toBe("NO_TOKEN");
  });

  test("should return 401 when token is invalid", async () => {
    const response = await request(app)
      .get("/api/v1/auth/me")
      .set("Authorization", "Bearer invalid-token");

    expect(response.status).toBe(401);
    expect(response.body.error.code).toBe("INVALID_TOKEN");
  });

  test("student should not be allowed to delete student", async () => {
    const token = generateToken({
      id: 1,
      email: "student@test.com",
      role: "student",
    });

    const response = await request(app)
      .delete("/api/v1/students/1")
      .set("Authorization", `Bearer ${token}`);

    expect(response.status).toBe(403);
  });
});
