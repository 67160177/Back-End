const {
  hashPassword,
  verifyPassword,
  generateToken,
} = require("./auth-helpers");

describe("Auth Helpers", () => {
  test("hashPassword should hash password", async () => {
    const password = "Passw0rd!";
    const hash = await hashPassword(password);

    expect(hash).not.toBe(password);
    expect(hash).toBeDefined();
  });

  test("verifyPassword should return true for correct password", async () => {
    const password = "Passw0rd!";
    const hash = await hashPassword(password);

    const result = await verifyPassword(password, hash);

    expect(result).toBe(true);
  });

  test("verifyPassword should return false for wrong password", async () => {
    const password = "Passw0rd!";
    const hash = await hashPassword(password);

    const result = await verifyPassword("WrongPassword!", hash);

    expect(result).toBe(false);
  });

  test("generateToken should create JWT token", () => {
    const token = generateToken({
      id: 1,
      email: "test@example.com",
      role: "student",
    });

    expect(token).toBeDefined();
    expect(typeof token).toBe("string");
    expect(token.split(".")).toHaveLength(3);
  });
});
