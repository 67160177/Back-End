jest.mock("./db");

const pool = require("./db");
const request = require("supertest");
const app = require("./app");

describe("Student Enrollment API", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  function createMockConnection() {
    return {
      beginTransaction: jest.fn().mockResolvedValue(),
      query: jest.fn(),
      commit: jest.fn().mockResolvedValue(),
      rollback: jest.fn().mockResolvedValue(),
      release: jest.fn(),
    };
  }

  test("should enroll student successfully", async () => {
    const connection = createMockConnection();

    connection.query
      .mockResolvedValueOnce([
        [
          {
            id: 1,
            course_id: 1,
            seat_available: 20,
          },
        ],
      ])
      .mockResolvedValueOnce([[]])
      .mockResolvedValueOnce([{ insertId: 100 }]);

    pool.getConnection.mockResolvedValueOnce(connection);

    const response = await request(app)
      .post("/api/v1/students/1/enrollments")
      .send({
        course_id: 1,
      });

    expect(response.status).toBe(201);
    expect(connection.beginTransaction).toHaveBeenCalled();
    expect(connection.commit).toHaveBeenCalled();
    expect(connection.release).toHaveBeenCalled();
  });

  test("should return 404 when course not found", async () => {
    const connection = createMockConnection();

    connection.query.mockResolvedValueOnce([[]]);

    pool.getConnection.mockResolvedValueOnce(connection);

    const response = await request(app)
      .post("/api/v1/students/1/enrollments")
      .send({
        course_id: 999,
      });

    expect(response.status).toBe(404);
    expect(connection.rollback).toHaveBeenCalled();
    expect(connection.release).toHaveBeenCalled();
  });

  test("should reject when course is full", async () => {
    const connection = createMockConnection();

    connection.query.mockResolvedValueOnce([
      [
        {
          id: 1,
          course_id: 1,
          seat_available: 0,
        },
      ],
    ]);

    pool.getConnection.mockResolvedValueOnce(connection);

    const response = await request(app)
      .post("/api/v1/students/1/enrollments")
      .send({
        course_id: 1,
      });

    expect(response.status).toBe(409);
    expect(connection.rollback).toHaveBeenCalled();
  });

  test("should rollback when database error occurs", async () => {
    const connection = createMockConnection();

    connection.query.mockRejectedValueOnce(new Error("Transaction error"));

    pool.getConnection.mockResolvedValueOnce(connection);

    const response = await request(app)
      .post("/api/v1/students/1/enrollments")
      .send({
        course_id: 1,
      });

    expect(response.status).toBe(500);
    expect(connection.rollback).toHaveBeenCalled();
    expect(connection.release).toHaveBeenCalled();
  });
  test("should reject duplicate enrollment", async () => {
    const connection = createMockConnection();

    connection.query
      .mockResolvedValueOnce([
        [
          {
            id: 1,
            course_id: 1,
            seat_available: 20,
          },
        ],
      ])
      .mockRejectedValueOnce(Object.assign(new Error("Duplicate"), { code: "ER_DUP_ENTRY" }));

    pool.getConnection.mockResolvedValueOnce(connection);

    const response = await request(app)
      .post("/api/v1/students/1/enrollments")
      .send({
        course_id: 1,
      });

    expect(response.status).toBe(409);
    expect(connection.rollback).toHaveBeenCalled();
    expect(connection.release).toHaveBeenCalled();
  });
});
