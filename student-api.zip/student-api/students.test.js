jest.mock("./db");

const pool = require("./db");
const request = require("supertest");
const app = require("./app");

describe("GET /api/v1/students", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("should return students", async () => {
    pool.query.mockResolvedValueOnce([
      [
        {
          id: 1,
          name: "สมชาย ใจดี",
          major: "IT",
          email: "somchai@example.com",
        },
        {
          id: 2,
          name: "สมหญิง ใจงาม",
          major: "CS",
          email: "somying@example.com",
        },
      ],
    ]);
    pool.query.mockResolvedValueOnce([[{ total: 1 }]]);

    const response = await request(app).get("/api/v1/students");

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty("data");
  });

  test("should filter by major", async () => {
    pool.query.mockResolvedValueOnce([
      [
        {
          id: 1,
          name: "สมชาย ใจดี",
          major: "IT",
          email: "somchai@example.com",
        },
      ],
    ]);
    pool.query.mockResolvedValueOnce([[{ total: 1 }]]);

    const response = await request(app).get("/api/v1/students?major=IT");

    expect(response.status).toBe(200);
    expect(response.body.data).toHaveLength(1);

    expect(pool.query).toHaveBeenCalled();
  });

  test("should support pagination", async () => {
    pool.query.mockResolvedValueOnce([
      [
        {
          id: 3,
          name: "วิเชียร สุดหล่อ",
          major: "ITDI",
          email: "wichian@example.com",
        },
      ],
    ]);
    pool.query.mockResolvedValueOnce([[{ total: 1 }]]);

    const response = await request(app).get("/api/v1/students?page=2&limit=1");

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty("data");
  });

  test("should support descending sort", async () => {
    pool.query.mockResolvedValueOnce([
      [
        {
          id: 2,
          name: "สมหญิง ใจงาม",
          major: "CS",
          email: "somying@example.com",
        },
      ],
    ]);
    pool.query.mockResolvedValueOnce([[{ total: 1 }]]);

    const response = await request(app).get(
      "/api/v1/students?sort=name&order=desc",
    );

    expect(response.status).toBe(200);
  });

  test("invalid sort field should fallback to id", async () => {
    pool.query.mockResolvedValueOnce([
      [
        {
          id: 1,
          name: "สมชาย ใจดี",
          major: "IT",
          email: "somchai@example.com",
        },
      ],
    ]);
    pool.query.mockResolvedValueOnce([[{ total: 1 }]]);

    const response = await request(app).get(
      "/api/v1/students?sort=DROP_TABLE&order=desc",
    );

    expect(response.status).toBe(200);

    const sql = pool.query.mock.calls[0][0];

    expect(sql).toContain("ORDER BY id");
  });

  test("database error should return 500", async () => {
    pool.query.mockRejectedValueOnce(new Error("Database error"));

    const response = await request(app).get("/api/v1/students");

    expect(response.status).toBe(500);
  });
  test("should use default pagination for invalid values", async () => {
    pool.query.mockResolvedValueOnce([[]]);
    pool.query.mockResolvedValueOnce([[{ total: 1 }]]);

    const response = await request(app).get(
      "/api/v1/students?page=abc&limit=abc",
    );

    expect(response.status).toBe(200);
  });

  test("should use ASC order when order is not desc", async () => {
    pool.query.mockResolvedValueOnce([[]]);
    pool.query.mockResolvedValueOnce([[{ total: 1 }]]);

    const response = await request(app).get(
      "/api/v1/students?sort=name&order=wrong",
    );

    expect(response.status).toBe(200);

    const sql = pool.query.mock.calls[0][0];

    expect(sql).toContain("ORDER BY name ASC");
  });
});
