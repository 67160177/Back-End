// ใช้โควตาจริงของ rate limiter (ไม่ใช่ค่าที่ขยายไว้สำหรับ NODE_ENV=test)
process.env.NODE_ENV = "development";

jest.mock("./db");
jest.mock("./cache", () => ({
  redisClient: { del: jest.fn().mockResolvedValue(1) },
}));

const pool = require("./db");
const request = require("supertest");
const app = require("./app");

describe("POST /api/v1/students - Zod validation", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("International major without passportNumber should return 400", async () => {
    const response = await request(app).post("/api/v1/students").send({
      name: "John Smith",
      email: "john@example.com",
      major: "International Business",
    });

    expect(response.status).toBe(400);
    expect(response.body).toEqual({
      error: {
        code: "VALIDATION_ERROR",
        message: "ข้อมูลที่ส่งมาไม่ถูกต้อง",
        details: [
          {
            field: "passportNumber",
            message: "ต้องระบุ passportNumber สำหรับสาขานานาชาติ",
          },
        ],
      },
    });
    expect(pool.query).not.toHaveBeenCalled();
  });

  test("International major with passportNumber should return 201", async () => {
    pool.query.mockResolvedValueOnce([{ insertId: 11 }]);

    const response = await request(app).post("/api/v1/students").send({
      name: "John Smith",
      email: "john@example.com",
      major: "International Business",
      passportNumber: "AA1234567",
    });

    expect(response.status).toBe(201);
    // passportNumber ใช้ validate เท่านั้น ไม่ถูกนำไป INSERT
    expect(pool.query.mock.calls[0][1]).toEqual([
      "John Smith",
      "International Business",
      "john@example.com",
    ]);
  });

  test("non-International major does not require passportNumber", async () => {
    pool.query.mockResolvedValueOnce([{ insertId: 12 }]);

    const response = await request(app).post("/api/v1/students").send({
      name: "Somchai",
      email: "somchai@example.com",
      major: "IT",
    });

    expect(response.status).toBe(201);
  });

  test("invalid email should report email field", async () => {
    const response = await request(app).post("/api/v1/students").send({
      name: "Somchai",
      email: "not-an-email",
      major: "IT",
    });

    expect(response.status).toBe(400);
    expect(response.body.error.details[0].field).toBe("email");
  });
});

describe("Rate limiter - separate quotas", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("authLimiter blocks the 6th login with 429 and RateLimit header", async () => {
    for (let i = 1; i <= 5; i++) {
      pool.query.mockResolvedValueOnce([[]]);

      const response = await request(app).post("/api/v1/auth/login").send({
        email: "attacker@example.com",
        password: `guess-${i}`,
      });

      expect(response.status).toBe(401);
    }

    const blocked = await request(app).post("/api/v1/auth/login").send({
      email: "attacker@example.com",
      password: "guess-6",
    });

    expect(blocked.status).toBe(429);
    expect(blocked.body.error.code).toBe("TOO_MANY_REQUESTS");
    expect(blocked.headers["ratelimit"]).toMatch(
      /limit=5, remaining=0, reset=\d+/,
    );
  });

  test("generalLimiter still allows other endpoints after login is blocked", async () => {
    pool.query
      .mockResolvedValueOnce([[]])
      .mockResolvedValueOnce([[{ total: 0 }]]);

    const response = await request(app).get("/api/v1/students");

    expect(response.status).toBe(200);
    expect(response.headers["ratelimit"]).toMatch(/limit=100, remaining=\d+/);
  });
});
