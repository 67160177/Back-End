jest.mock("./db");

const pool = require("./db");
const request = require("supertest");
const app = require("./app");

describe("Authentication API", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("POST /api/v1/auth/register - validation error", async () => {
    const response = await request(app).post("/api/v1/auth/register").send({
      email: "test@example.com",
    });

    expect(response.status).toBe(400);
  });

  test("POST /api/v1/auth/login - user not found", async () => {
    pool.query.mockResolvedValueOnce([[]]);

    const response = await request(app).post("/api/v1/auth/login").send({
      email: "notfound-test@example.com",
      password: "Passw0rd!",
    });

    expect(response.status).toBe(401);
  });

  test("GET /api/v1/auth/me - no token", async () => {
    const response = await request(app).get("/api/v1/auth/me");

    expect(response.status).toBe(401);
  });

  test("POST /api/v1/auth/register - success", async () => {
    pool.query.mockResolvedValueOnce([{ insertId: 1 }]);

    const response = await request(app).post("/api/v1/auth/register").send({
      email: "branch@example.com",
      password: "Passw0rd!",
      role: "student",
    });

    expect(response.status).toBe(201);
  });

  test("POST /api/v1/auth/register - duplicate email", async () => {
    pool.query.mockRejectedValueOnce(
      Object.assign(new Error("Duplicate entry"), { code: "ER_DUP_ENTRY" }),
    );

    const response = await request(app).post("/api/v1/auth/register").send({
      email: "duplicate@example.com",
      password: "Passw0rd!",
    });

    expect(response.status).toBe(409);
  });

  test("POST /api/v1/auth/login - missing password", async () => {
    const response = await request(app).post("/api/v1/auth/login").send({
      email: "test@example.com",
    });

    expect(response.status).toBe(400);
  });
});
