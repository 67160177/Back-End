jest.mock("./db");

const pool = require("./db");
const request = require("supertest");
const app = require("./app");
const { hashPassword } = require("./auth-helpers");

describe("POST /api/v1/auth/login - Mocked DB", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("login success should return token", async () => {
    const password = "Passw0rd!";
    const hashedPassword = await hashPassword(password);

    pool.query.mockResolvedValueOnce([
      [
        {
          id: 1,
          email: "mocked@example.com",
          password_hash: hashedPassword,
          role: "student",
        },
      ],
    ]);

    const response = await request(app).post("/api/v1/auth/login").send({
      email: "mocked@example.com",
      password,
    });

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty("token");
  });

  test("login user not found should return 401", async () => {
    pool.query.mockResolvedValueOnce([[]]);

    const response = await request(app).post("/api/v1/auth/login").send({
      email: "notfound@example.com",
      password: "Passw0rd!",
    });

    expect(response.status).toBe(401);
  });

  test("login database error should return 500", async () => {
    pool.query.mockRejectedValueOnce(new Error("Connection lost"));

    const response = await request(app).post("/api/v1/auth/login").send({
      email: "error@example.com",
      password: "Passw0rd!",
    });

    expect(response.status).toBe(500);
  });
});
